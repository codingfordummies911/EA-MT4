//+------------------------------------------------------------------+
//|                                              Gann HiLo Activator |
//|                                                                  |
//+------------------------------------------------------------------+
#property copyright "www.forex-station.com"
#property link      "www.forex-station.com"

#property indicator_chart_window
#property indicator_buffers 3
#property indicator_color1  clrMediumBlue
#property indicator_color2  clrFireBrick
#property indicator_color3  clrGold
#property indicator_width1  3
#property indicator_width2  3
#property indicator_width3  3
#property strict

//
//
//
//
//

extern ENUM_TIMEFRAMES TimeFrame       = PERIOD_CURRENT;    // Time frame to use?
extern int             Lb              = 11;                // Gann look back?
extern bool            alertsOn        = true;              // Turn alerts on?
extern bool            alertsOnCurrent = false;             // Alerts on current (still opened) bar?
extern bool            alertsMessage   = true;              // Alerts should display a message?
extern bool            alertsSound     = true;              // Alerts should play a sound?
extern bool            alertsEmail     = false;             // Alerts should send an email?
extern bool            alertsNotify    = false;             // Alerts should send notification?
extern bool            Interpolate     = true;              // Interpolate in multi time frame mode?


double gup[],gdna[],gdnb[],trend[],count[];
string indicatorFileName;
#define _mtfCall(_buff,_ind) iCustom(NULL,TimeFrame,indicatorFileName,PERIOD_CURRENT,Lb,alertsOn,alertsOnCurrent,alertsMessage,alertsSound,alertsEmail,alertsNotify,_buff,_ind)

//+------------------------------------------------------------------
//|                                                                  
//+------------------------------------------------------------------
//
//
//
//
//

int init()
{
   IndicatorBuffers(5);
   SetIndexBuffer(0,gup);  
   SetIndexBuffer(1,gdna);
   SetIndexBuffer(2,gdnb); 
   SetIndexBuffer(3,trend);
   SetIndexBuffer(4,count);
   
   indicatorFileName = WindowExpertName();
   TimeFrame         = fmax(TimeFrame,_Period); 
   
   IndicatorShortName(timeFrameToString(TimeFrame)+"  GannHiLoActivator  ("+(string)Lb+")");
return(0);
}

//+------------------------------------------------------------------
//|                                                                  
//+------------------------------------------------------------------
//
//
//
//
//

int start()
{
    int i,counted_bars=IndicatorCounted();
      if(counted_bars<0) return(-1);
      if(counted_bars>0) counted_bars--;
         int limit = fmin(Bars-counted_bars,Bars-1); count[0]=limit;
            if (TimeFrame!=_Period)
            {
               limit = (int)fmax(limit,fmin(Bars-1,_mtfCall(4,0)*TimeFrame/_Period));
               if (trend[limit]==-1) CleanPoint(limit,gdna,gdnb);
               for (i=limit;i>=0 && !_StopFlag; i--)
               {
                  int y = iBarShift(NULL,TimeFrame,Time[i]);
                     gup[i]   = _mtfCall(0,y);
                     gdna[i]  = EMPTY_VALUE;
                     gdnb[i]  = EMPTY_VALUE;
                     trend[i] = _mtfCall(3,y);
                     
                     //
                     //
                     //
                     //
                     //
                     
                      if (!Interpolate || (i>0 && y==iBarShift(NULL,TimeFrame,Time[i-1]))) continue;
                      #define _interpolate(buff) buff[i+k] = buff[i]+(buff[i+n]-buff[i])*k/n
                      int n,k; datetime time = iTime(NULL,TimeFrame,y);
                         for(n = 1; (i+n)<Bars && Time[i+n] >= time; n++) continue;	
                         for(k = 1; k<n && (i+n)<Bars && (i+k)<Bars; k++) _interpolate(gup);                                             
            }
            for(i=limit; i>=0; i--) if (trend[i] == -1) PlotPoint(i,gdna,gdnb,gup);
      return(0);
      }
      
      //
      //
      //
      //
      //
      
      if (trend[limit]==-1) CleanPoint(limit,gdna,gdnb);
      for(i=limit;i>=0;i--)
      {
         gdna[i]  = EMPTY_VALUE;
         gdnb[i]  = EMPTY_VALUE;
         trend[i] = (i<Bars-1) ? (Close[i]>iMA(NULL,0,Lb,0,MODE_SMA,PRICE_HIGH,i+1)) ? 1 : (Close[i]<iMA(NULL,0,Lb,0,MODE_SMA,PRICE_LOW, i+1)) ? -1 : trend[i+1] : 0;
         
         if(i<Bars-1 && trend[i] == -1)
               gup[i] = iMA(Symbol(),0,Lb,0,MODE_SMA,PRICE_HIGH,i+1);
         else  gup[i] = iMA(Symbol(),0,Lb,0,MODE_SMA,PRICE_LOW, i+1);
         if (trend[i]==-1) PlotPoint(i,gdna,gdnb,gup);
      }
manageAlerts();
return(0);
}      

   
//-------------------------------------------------------------------
//                                                                  
//-------------------------------------------------------------------
//
//
//
//
//

void CleanPoint(int i,double& first[],double& second[])
{
   if (i>=Bars-3) return;
   if ((second[i]  != EMPTY_VALUE) && (second[i+1] != EMPTY_VALUE))
        second[i+1] = EMPTY_VALUE;
   else
      if ((first[i] != EMPTY_VALUE) && (first[i+1] != EMPTY_VALUE) && (first[i+2] == EMPTY_VALUE))
          first[i+1] = EMPTY_VALUE;
}

void PlotPoint(int i,double& first[],double& second[],double& from[])
{
   if (i>=Bars-2) return;
   if (first[i+1] == EMPTY_VALUE)
      if (first[i+2] == EMPTY_VALUE) 
            { first[i]  = from[i];  first[i+1]  = from[i+1]; second[i] = EMPTY_VALUE; }
      else  { second[i] =  from[i]; second[i+1] = from[i+1]; first[i]  = EMPTY_VALUE; }
   else     { first[i]  = from[i];                           second[i] = EMPTY_VALUE; }
}


//-------------------------------------------------------------------
//                                                                  
//-------------------------------------------------------------------
//
//
//
//
//

string sTfTable[] = {"M1","M5","M15","M30","H1","H4","D1","W1","MN"};
int    iTfTable[] = {1,5,15,30,60,240,1440,10080,43200};

string timeFrameToString(int tf)
{
   for (int i=ArraySize(iTfTable)-1; i>=0; i--) 
         if (tf==iTfTable[i]) return(sTfTable[i]);
                              return("");
}

//-------------------------------------------------------------------
//                                                                  
//-------------------------------------------------------------------
//
//
//
//
//

void manageAlerts()
{
   if (alertsOn)
   {
      int whichBar = 1; if (alertsOnCurrent) whichBar = 0;
      if (trend[whichBar] != trend[whichBar+1])
      {
         if (trend[whichBar] ==  1) doAlert(whichBar,"  Up  .:BUY:.");
         if (trend[whichBar] == -1) doAlert(whichBar,"  Down  .:SELL:.");
      }
   }
}

//
//
//
//
//

void doAlert(int forBar, string doWhat)
{
   static string   previousAlert="nothing";
   static datetime previousTime;
   string message;
   
   if (previousAlert != doWhat || previousTime != Time[forBar]) {
       previousAlert  = doWhat;
       previousTime   = Time[forBar];

       //
       //
       //
       //
       //

       message =  StringConcatenate(Symbol()," ",timeFrameToString(_Period),"   at   ",TimeToStr(TimeLocal(),TIME_SECONDS),"   GannHiLoActivator    TrendChangedTo   ",doWhat);
          if (alertsMessage) Alert(message);
          if (alertsSound)   PlaySound("alert2.wav");
          if (alertsEmail)   SendMail(StringConcatenate(Symbol(),"   GannHiLoActivator   "),message);
          if (alertsNotify)  SendNotification(message);
   }
}